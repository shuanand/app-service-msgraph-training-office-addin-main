authConfig = {
  clientId: '77fd18bf-b400-4325-ae1a-acf55a4ae458'
};
